<!doctype html>
<html lang="en">
<head>
    <title>KWIKRIDE Landing Page</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="description" content="Skylar">
    <meta name="robots" content="index, follow">
    <meta name="copyright" content="Skylar">
    <meta name="application-name" content="Skylar">
    <link rel="icon" href="./website/images/favicon.png'" type="image/png">
    <link rel="stylesheet" href="./website/css/style.css'">
    <link rel="stylesheet" href="./website/css/responsive.css">
    <link rel="stylesheet" href="./website/css/bootstrap.min.css')">
    <link rel="stylesheet" href="./website/css/styles.css')">
    <link rel="stylesheet" href="./website/css/font-awesome.min.css'">
    <link rel="stylesheet" href="./website/css/loaders.min.css">
    <link rel="stylesheet" href="./website/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="./website/revolution/css/settings.css" media="screen">
    <link rel="stylesheet" type="text/css" href="./website/revolution/css/navigation.css">
    <link href="./website/css/jquery.frame-carousel.min.css" rel="stylesheet">
    <style type="text/css">
        .white {
            color: #fff;
        }
        .link {
            text-decoration: none;
        }
        .link:hover {
            text-decoration: underline;
            color: #fff;
        }
        .round-corners {
            border-radius: 10px;
        }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            margin: 0;
        }
    </style>
    <script type="application/ld+json">
{
	"@context": "http://schema.org",
  	"@type": "Organization",
  	"name": "Skylar",
  	"url": "https://www.skylar.com",
  	"logo": "https://www.skylar.com/images/favicon.png",
  	"address": {
  		"@type": "PostalAddress",
		"streetAddress": "",
		"addressLocality": "",
		"addressRegion": "",
		"postalCode": "",
		"addressCountry": ""
  	},
  	"email": "",
  	"description": "",
  	"sameAs": [
  		"https://www.facebook.com/",
  		"https://www.instagram.com/"
  	],
  	"contactPoint": [{
	    "@type": "ContactPoint",
	    "telephone": "",
	    "contactType": "customer service",
	    "areaServed": "",
	    "availableLanguage": ["English"]
  	}]
}
</script>
</head>
<body data-target="#main-navbar">
<!-- Preloader -->
<div class="loader bg-white">
    <div class="loader-inner ball-pulse ball-pulse-color">
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<div id="page" class="light-version">
    <header id="nav" class="light-nav">
        <nav class="navbar navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">

                    <button type="button" class="collapse navbar-toggle navbar-icon" data-toggle="collapse" data-target="#navbar-collapse"></button>

                    <div class="logo"><a href=""><img src="{{ asset('website/images/logo.png') }}" width="50" alt="skylar logo"></a><p><span class="logo_">KWIKRIDE</span></p></div>

                </div>

                <div class="collapse navbar-collapse-md" id="navbar-collapse">

                    <ul class="nav navbar-nav navbar-left">
                        <li><a href="#features" class="smooth-scroll">Features</a></li>
                        <li><a href="#user-app" class="smooth-scroll">User App</a></li>
                        <li><a href="#download" class="smooth-scroll">Download</a></li>
                        <li><a href="#screenshots" class="smooth-scroll">Screenshots</a></li>
                        <li><a href="#contact" class="smooth-scroll">Contact Us</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <ul class="social">
                                <li><a class="btn-circle btn-circle-sm btn-color" href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li><a class="btn-circle btn-circle-sm btn-color" href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                <li><a class="btn-circle btn-circle-sm btn-color" href="https://www.linkedin.com/company/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                <li><a class="btn-circle btn-circle-sm btn-color" href="https://instagram.com/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </li>
                    </ul>

                </div>

            </div>
        </nav>
    </header>

    <section id="hero-slider" class="bg-light" style="background-image:url({{ asset('website/images/header.jpg') }}); background-attachment:fixed; background-size:cover; background-position-y: -128px;">
        <div class="content" style="background: rgba(0, 0, 0, 0.6);">
            <div class="rev_slider_wrapper">
                <div id="slider" class="rev_slider">
                    <ul>
                        <li data-transition="fade">
                            <div class="tp-caption text-center-md"
                                 id="slide-3-layer-1"
                                 data-x="['right','right','center','center']"
                                 data-hoffset="['15','15','0','0']"
                                 data-y="['center','center','center','center']"
                                 data-voffset="['20','20','180','180']"
                                 data-width="['550',450','670','532']"
                                 data-height="none"
                                 data-transform_idle="o:1;"
                                 data-whitespace="normal"
                                 data-transform_in="x:100px;opacity:0;s:1000;e:Power3.easeOut;"
                                 data-transform_out="x:100px;opacity:0;s:1000;e:Power3.easeOut;"
                                 data-start="1200"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-responsive_offset="off">
                                <h1>Company Tagline</h1>
                                <div class="wrapper-v-lg white">Move The Way You Want. Anytime. Anywhere. </div>
                            </div>
                            <div class="tp-caption"
                                 id="slide-3-layer-2"
                                 data-x="['center','center','center','center']"
                                 data-hoffset="['-310','-260','0','0']"
                                 data-y="['center','center','center','center']"
                                 data-voffset="['0','0','-165','-165']"
                                 data-width="none"
                                 data-height="none"
                                 data-basealign="grid"
                                 data-transform_idle="o:1;"

                                 data-transform_in="x:-100px;opacity:0;s:1500;e:Power3.easeOut;"
                                 data-transform_out="x:-100px;opacity:0;s:1500;e:Power3.easeOut;"
                                 data-start="800"
                                 data-responsive_offset="off"><img width="350" src="{{ asset('website/images/skylar-home.png') }}"
                                                                   alt="skylar android app"
                                                                   data-hh="none"
                                                                   data-ww="['300','300','290','290']"
                                                                   data-no-retina> </div>

                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </section>



    <section id="features" class="section-p-lg">
        <div class="container wrapper-h-xs-lg reveal-bottom-opacity">
            <div class="row">

                <div class="col-md-6 col-md-offset-0 col-sm-8 col-sm-offset-2 wrapper-v-lg">
                    <div class="function-device-shadow"> <img src="{{ asset('website/images/skylar-android-app-skew.png') }}" class="img-responsive reveal-top-20" alt="skylar android app"> </div>
                </div>

                <div class="col-md-6 col-sm-12 wrapper-v-lg">

                    <h2>APP FEATURES</h2>
                    <p>Our app is equipped with the most interesting and beneficial features. Some of the highlighted features are:</p>
                    <div class="row">

                        <div class="col-xs-6 wrapper-v-lg">

                            <div class="icon-sm icon-color"><img src="{{ asset('website/images/driver.png') }}" alt="driver"></div>

                            <p><strong>Book Later Rides:</strong> Users can choose to book their rides now or later. Our app will automatically process the request and dispatch it to available drivers.</p>

                        </div>

                        <div class="col-xs-6 wrapper-v-lg">

                            <div class="icon-sm icon-color"><img src="{{ asset('website/images/gps.png') }}" alt="app navigation"></div>

                            <p><strong>In App Navigation:</strong> Using in-app GPS functionality, users can track their ride status.</p>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-xs-6 wrapper-v-lg">

                            <div class="icon-sm icon-color"><img src="{{ asset('website/images/secure-payment.png') }}" alt="secure payment"></div>

                            <p><strong>Secure Payment Systems:</strong> Your online payment information is securely stored in payment gateway's vault. All details are stored in encrypted form in database for secured payment process.</p>

                        </div>

                        <div class="col-xs-6 wrapper-v-lg">
                            <div class="icon-sm icon-color"><img src="{{ asset('website/images/promo.png') }}" alt="promo referral codes"></div>

                            <p><strong>Promotion &amp; Referral Codes:</strong> Users can avail promotional and referral codes to get discount on their rides.</p>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-xs-6 wrapper-v-lg">

                            <div class="icon-sm icon-color"><img src="{{ asset('website/images/wallet.png') }}" alt="wallet"></div>

                            <p><strong>User Wallet:</strong> Wallet allows users to pay for their rides when they do not have Cash or Credit Card.</p>

                        </div>

                        <div class="col-xs-6 wrapper-v-lg">
                            <div class="icon-sm icon-color"><img src="{{ asset('website/images/in-app-notifications.png') }}" alt="in app notifications"> </div>

                            <p><strong>Push &amp; In-App Notifications:</strong> Push Notifications and In-App Notifications are the best and user-friendly way to convey major activities regarding ride status &amp; promotion codes.</p>

                        </div>

                    </div>


                </div>

            </div>
        </div>
    </section>


    <section id="user-app" class="bg-lightgrey section-p-lg">
        <div class="container wrapper-h-xs-lg reveal-bottom-opacity">
            <div class="row">

                <div class="col-sm-8 col-sm-offset-2 wrapper-v-lg text-center">
                    <h2>Feature Packed. With Latest UI/UX.</h2><br>
                    <p>Our app makes your ride a breeze with multiple options of cabs at affordable prices.<br>Choose Skylar to get around in style.</p>
                </div>

            </div>
            <div class="row vert-middle-md">

                <div class="col-md-3 col-sm-6 features-left wrapper-v-md wrapper-h-xs-lg">
                    <div class="reveal-left-10">

                        <div class="icon-md icon-color"><img src="{{ asset('website/images/estimate.png') }}" alt="ride estimate"></div>

                        <h4>Ride Estimation</h4>
                        <p>Ride fare estimation can be checked by users before booking their ride. Estimate is based on the car type they select and distance between start location and destination.</p>


                        <div class="icon-md icon-color"><img src="{{ asset('website/images/transactions.png') }}" alt="transactions"></div>

                        <h4>Track Transaction</h4>
                        <p>Complete and detailed transaction history of previous rides is available to users. Invoices include route details, tips, and billing amount.</p>

                        <div class="icon-md icon-color"><img src="{{ asset('website/images/notifications.png') }}" alt="ride notifications"></div>

                        <h4>Instant Alert on Ride Status</h4>
                        <p>Our taxi app provide instant alerts to users in the event of any major updates to their ride status in the form of notifications.</p>


                    </div>
                </div>

                <div class="col-md-3 col-md-push-6 col-sm-6  wrapper-v-md features-right wrapper-h-xs-lg">
                    <div class="reveal-right-10">

                        <div class="icon-md icon-color"><img src="{{ asset('website/images/online-payment.png') }}" alt="online payment modes"></div>

                        <h4>Cash, Wallet &amp; Payment Gateways</h4>
                        <p>Multiple convenient payment methods like Cash, Wallet &amp; third-party Payment Gateways are integrated in Company Name.</p>

                        <div class="icon-md icon-color"> <img src="{{ asset('website/images/arrival.png') }}" alt="estimated time of arrival"> </div>

                        <h4>Estimated Time of Arrival</h4>
                        <p>Our app notifies the accurate arrival time of drivers to user on their pickup location, both before and after completion of booking.</p>

                        <div class="icon-md icon-color"> <img src="{{ asset('website/images/ride-history.png') }}" alt="ride history"></div>

                        <h4>Detailed Ride History</h4>
                        <p>Complete and detailed history of rides can be viewed by user in their profile. It includes information like pick up, drop location, ride and wait timings, distance travelled, tips (if any) and fare break up.</p>


                    </div>
                </div>
                <div
                        class="col-md-6 col-md-offset-0 col-md-pull-3 col-sm-8 col-sm-offset-2 text-center wrapper-v-lg">
                    <div class="row">
                        <div class="col-lg-10 col-lg-offset-1 wrapper-h-xs-lg">

                            <div class="col-lg-8">
                                <div class="fc-portrait"></div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section id="download" class="bg-white section-p-lg">
        <div class="container wrapper-h-xs-lg reveal-bottom-opacity">
            <div class="row">

                <div class="col-sm-8 col-sm-offset-2 wrapper-v-lg text-center">
                    <h2>Download Application</h2>
                </div>
                <div class="col-sm-6 col-sm-offset-3 wrapper-v-lg text-center"><a href="" target="_blank"><img src="{{ asset('website/images/google-play-badge.png') }}" width="200"></a></div>
            </div>

        </div>
    </section>


    <section id="screenshots" class="bg-lightgrey section-p-lg">
        <div class="container wrapper-h-xs-lg reveal-bottom-opacity">
            <div class="row">

                <div class="col-md-8 col-md-offset-2 wrapper-v-lg text-center">
                    <h2>Screenshots</h2>

                    <p></p>
                </div>

                <div class="col-md-12 wrapper-v-lg">

                    <div class="gallery-slider owl-carousel owl-theme">

                        <div class="item">
                            <img src="{{ asset('website/images/skylar-home-screen.png') }}" class="img-responsive round-corners" alt="skylar android app, home screen">
                        </div>
                        <div class="item">
                            <img src="{{ asset('website/images/skylar-cab-book.png') }}" class="img-responsive round-corners" alt="skylar android app, cab booking">
                        </div>
                        <div class="item">
                            <img src="{{ asset('website/images/skylar-payment-methods.png') }}" class="img-responsive round-corners" alt="skylar android app, payment methods">
                        </div>
                        <div class="item">
                            <img src="{{ asset('website/images/skylar-price-card.png') }}" class="img-responsive round-corners" alt="skylar android app, cab price card">
                        </div>
                        <div class="item">
                            <img src="{{ asset('website/images/skylar-referral-code.png') }}" class="img-responsive round-corners" alt="skylar android app, referral code screen">
                        </div>
                        <div class="item">
                            <img src="{{ asset('website/images/skylar-find-ride.png') }}" class="img-responsive round-corners" alt="skylar android app, finding ride screen">
                        </div>
                        <div class="item">
                            <img src="{{ asset('website/images/skylar-payment-screen.png') }}" class="img-responsive round-corners" alt="skylar android app, payment screen">
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="bg-white">
        <div class="wrapper-h-xs-lg reveal-bottom-opacity">
            <div class="container-fluid"  style="padding-left:0px;">
                <div class="col-md-6" style="padding-left:0px; -webkit-filter: grayscale(100%); filter: grayscale(100%);"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127482.66722765865!2d101.61694883652328!3d3.1386749703972074!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc362abd08e7d3%3A0x232e1ff540d86c99!2sKuala+Lumpur%2C+Federal+Territory+of+Kuala+Lumpur%2C+Malaysia!5e0!3m2!1sen!2sin!4v1553066255311" width="100%" height="650" frameborder="0" style="border:0" allowfullscreen></iframe></div>
                <div class="col-md-5">
                    <div class="get_heading">
                        <h2>Contact Us</h2>
                    </div>
                    <form action="" id="contact-form" method="post">
                        <div class="row">
                            <div class="col-sm-6">
                            <div class="form-group" id="name-field">
                                    <label for="form-name" class="sr-only">Name</label>
                                    <input class="form-control form-control-silver" id="form-name" name="form-name" placeholder="Name" required type="text">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group" id="email-field">
                                    <label for="form-email" class="sr-only">Email</label>
                                    <input class="form-control form-control-silver" id="form-email" name="form-email" placeholder="Email" required type="email">
                                </div>
                            </div>
                            <div class="col-sm-6">

                                <div class="form-group" id="number-field">
                                    <label for="form-number" class="sr-only">Number</label>
                                    <input class="form-control form-control-silver" id="form-number" name="form-number" placeholder="Number" required type="number">
                                </div>

                            </div>

                            <div class="col-sm-6">

                                <div class="form-group" id="skype-field">
                                    <label for="form-skype" class="sr-only">Skype</label>
                                    <input class="form-control form-control-silver" id="form-skype" name="form-skype" placeholder="Skype (Optional)" type="text">
                                </div>

                            </div>

                            <div class="col-sm-12" style="padding-bottom:40px;">

                                <div class="form-group" id="message-field">
                                    <label for="form-message" class="sr-only">Message</label>
                                    <textarea class="form-control form-control-silver" rows="6" id="form-message" name="form-message" placeholder="Message" required></textarea>
                                </div>

                                <div class="form-group">
                                    <div id="message-contact" class="message text-center"> <span class="message-icon"><i class="fa fa-info"></i></span> <span class="message-text"></span> </div>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-color" style="float:right;">Submit</button>
                                </div>

                            </div>

                            <div class="col-sm-6 wrapper-v-sm block-line">

                                <div class="block icon-md icon-color"> <img src="{{ asset('website/images/address.png') }}" alt="address"> </div>
                                <div class="block text-left">
                                    <p>Address line 1<br>Address line 2<br>Address line 3<br>Address line 4</p>
                                </div>

                            </div>

                            <div class="col-sm-6 wrapper-v-sm block-line">

                                <div class="block icon-md icon-color"> <img src="{{ asset('website/images/contact.png') }}" alt="contact"> </div>

                                <div class="block text-left">
                                    <p>Call: <a class="link-dark" href="tel:">+xx-xxxxx xxx</a><br>Email: <a class="link-dark" href="mailto:" target="_blank">hello@example.com</a>
                                    </p>
                                </div>

                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>





    <footer id="footer" class="bg-dark section-p-sm text-white">
        <div class="container">
            <div class="row">

                <div class="col-md-12 wrapper-v-sm text-center">
                    <p>Made with <i class="fa fa-heart" style="color:red;"></i> in India.</p>
                    <p><a href="https://www.skylar.com" class="white link" target="_blank">Skylar</a> &copy; <span id="year"></span>. All Rights Reserved.</p>
                </div>



            </div>
        </div>
    </footer>
</div>

<!-- Back to Top Button -->
<a href="#page" class="btn-circle btn-circle-lg btn-color btn-top smooth-scroll"><i class="fa fa-angle-up"></i> </a>

<!-- Scripts -->
<script type="text/javascript">
    var d = new Date();
    var n = d.getFullYear();
    document.getElementById("year").innerHTML = n;
</script>
<script src="./website/js/jquery1.11.2.min.js"></script>
<script src="./website/js/bootstrap.min.js"></script>
<script src="./website/js/circles.min.js"></script>
<script src="./website/js/owl.carousel.min.js"></script>
<script src="./website/js/scrollreveal.min.js"></script>
<script src="./website/js/ua-parser.min.js"></script>
<script src="./'website/js/modernizr.js"></script>

<!-- RS5.0 Core JS Files -->
<script type="text/javascript" src="./website/revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="./website/revolution/js/jquery.themepunch.revolution.min.js"></script>
<!-- Custom Script -->
<script src="./website/js/custom.js"></script>

<script src="./website/js/jquery.frame-carousel.min.js"></script>

<script type="text/javascript">
    $(function(){
        $('.fc-portrait').frameCarousel({
            frame: '{{ asset('website/images/iphone.png') }}',
            boundingBox: {
                left: '6.5%',
                top: '12.2%',
                width: '86.8%',
                height: '75.3%'
            },
            frameSize: [{
                width: 300
            }],
            controlsPosition: {
                top: '45%'
            }
        });
    });
</script>
</body>
</html>